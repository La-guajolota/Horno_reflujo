/**
 * @file main.cpp
 * @brief Main firmware file for ESP8266 Web GUI project.
 *
 * @author Original: José Antonio García García
 * @author Refactored by: Adrián Silva Palafox
 * @date July 2025
 * @copyright Inbiodroid
 * @see https://github.com/La-guajolota/Horno_reflujo
 */
#include <Arduino.h>
#include <ESP8266WiFi.h>
#include <ESPAsyncTCP.h>
#include <ESPAsyncWebServer.h>
#include "config.h"
#include "websocket_handler.h"
#include "serial_handler.h"
#include "web_interface.h"

AsyncWebServer server(80);
AsyncWebSocket ws("/ws");

void setup()
{
  Serial.begin(115200);

  // Initialize WiFi
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  Serial.print("Conectando a WiFi");

  while (WiFi.status() != WL_CONNECTED)
  {
    delay(500);
    Serial.print(".");
  }

  Serial.println();
  // Serial.println("WiFi conectado!");
  Serial.print("IP: ");
  Serial.println(WiFi.localIP());

  // Configure WebSocket
  ws.onEvent(onWebSocketEvent);
  server.addHandler(&ws);

  // Configure main url
  server.on("/", HTTP_GET, [](AsyncWebServerRequest *request)
            { request->send_P(200, "text/html", index_html); });

  server.begin();
  Serial.println("Servidor web iniciado");
}

void loop()
{
  handleSerial();
  ws.cleanupClients();
}