/**
 * @file config.h
 * @brief Global configuration for the ESP01-based reflow oven firmware.
 *
 * This file contains WiFi, server, system state definitions, and global variables used in the project.
 */

#ifndef CONFIG_H
#define CONFIG_H

/** @name WiFi Configuration
 *  Parameters for WiFi connection.
 */
const char *WIFI_SSID = "Mega_2.4G_3512"; ///< WiFi network SSID
const char *WIFI_PASSWORD = "Ph5YcEUs";   ///< WiFi network password

/** @name Server Configuration
 *  Parameters for the web server and WebSocket.
 */
const int SERVER_PORT = 80;                    ///< HTTP server port
const unsigned long WEBSOCKET_INTERVAL = 1000; ///< WebSocket data send interval (ms)

/**
 * @enum ReflowState
 * @brief Possible states of the reflow process.
 */
enum ReflowState
{
    REFLOW_PREHEAT = 0,  /**< Preheat state */
    REFLOW_SOAK = 1,     /**< Soak state */
    REFLOW_HEATUP = 2,   /**< Heatup state */
    REFLOW_REFLOW = 3,   /**< Reflow state */
    REFLOW_COOLDOWN = 4, /**< Cooldown state */
    REFLOW_IDLE = 5      /**< Idle state */
};

/**
 * @var STATE_NAMES
 * @brief Descriptive names for the reflow states.
 */
const String STATE_NAMES[6] = {
    "REFLOW PREHEAT",
    "REFLOW SOAK",
    "REFLOW HEATUP",
    "REFLOW REFLOW",
    "REFLOW COOLDOWN",
    "REFLOW IDLE"};

/** @name Global Variables
 *  Variables shared between different system modules.
 */
extern String currentTemp;      ///< Current temperature as text
extern String currentStateText; ///< Current state as descriptive text
extern unsigned long lastSend;  ///< Timestamp of last data

#endif