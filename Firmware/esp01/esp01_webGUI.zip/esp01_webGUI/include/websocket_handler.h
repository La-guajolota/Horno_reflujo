/**
 * @file websocket_handler.h
 * @brief WebSocket handler for the ESP01-based reflow oven firmware.
 *
 * This file provides functions and event handlers for WebSocket communication,
 * enabling real-time updates and control between the ESP01 and web clients.
 *
 * - Manages global variables for temperature and state.
 * - Notifies all connected clients with the latest data.
 * - Handles incoming WebSocket events and commands.
 */

#ifndef WEBSOCKET_HANDLER_H
#define WEBSOCKET_HANDLER_H

#include <ESPAsyncWebServer.h>
#include "config.h"

// Global variables for current temperature, state, and last send timestamp
String currentTemp = "0.00";             ///< Current temperature as text
String currentStateText = "REFLOW IDLE"; ///< Current state as descriptive text
unsigned long lastSend = 0;              ///< Timestamp of last data send

// External WebSocket declaration
extern AsyncWebSocket ws;

/**
 * @brief Notifies all connected WebSocket clients with the latest temperature and state.
 *
 * Sends a JSON string with the current temperature and state if the minimum interval has passed.
 */
void notifyClients()
{
    unsigned long now = millis();
    if (now - lastSend >= WEBSOCKET_INTERVAL)
    {
        String data = "{\"temp\":\"" + currentTemp + "\",\"estado\":\"" + currentStateText + "\"}";
        ws.textAll(data);
        lastSend = now;
    }
}

/**
 * @brief Handles WebSocket events for connection, disconnection, and data reception.
 *
 * @param server Pointer to the AsyncWebSocket server.
 * @param client Pointer to the client triggering the event.
 * @param type   Type of WebSocket event.
 * @param arg    Additional event argument.
 * @param data   Pointer to received data.
 * @param len    Length of received data.
 */
void onWebSocketEvent(AsyncWebSocket *server, AsyncWebSocketClient *client,
                      AwsEventType type, void *arg, uint8_t *data, size_t len)
{
    switch (type)
    {
    case WS_EVT_CONNECT:
        Serial.println("WebSocket client connected");
        break;

    case WS_EVT_DISCONNECT:
        Serial.println("WebSocket client disconnected");
        break;

    case WS_EVT_DATA:
    {
        AwsFrameInfo *info = (AwsFrameInfo *)arg;
        if (info->final && info->index == 0 && info->len == len)
        {
            String msg = "";
            for (size_t i = 0; i < len; i++)
            {
                msg += (char)data[i];
            }

            // Process commands from client
            if (msg == "START")
            {
                Serial.println("B1");
            }
            else if (msg == "STOP")
            {
                Serial.println("B0");
            }
            else if (msg.startsWith("p") || msg.startsWith("i") || msg.startsWith("d"))
            {
                Serial.println(msg);
            }
            else if (msg.length() >= 2 && isAlpha(msg.charAt(0)))
            {
                Serial.println(msg);
            }
        }
        break;
    }

    default:
        break;
    }
}

#endif