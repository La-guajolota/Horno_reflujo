/**
 * @file serial_handler.h
 * @brief Serial input handler for the ESP01-based reflow oven firmware.
 *
 * This file provides the function to process serial input, parse temperature and state data,
 * and update global variables accordingly.
 */

#ifndef SERIAL_HANDLER_H
#define SERIAL_HANDLER_H

#include <Arduino.h>
#include "config.h"
#include "websocket_handler.h"

/**
 * @brief Handles incoming serial data, parses temperature and state, and updates global variables.
 *
 * Expected serial input format: t<float_value>E<int_value>
 * Example: t123.45E2
 *
 * - 't' marks the start of a temperature value.
 * - 'E' separates the temperature from the state value.
 * - On receiving a newline or carriage return, the input is parsed.
 * - If valid, updates @ref currentTemp and @ref currentStateText, and notifies WebSocket clients.
 */
void handleSerial()
{
    static String input = "";

    while (Serial.available())
    {
        char c = Serial.read();

        if (c == '\n' || c == '\r')
        {
            // Parse input if it matches the expected format
            if (input.startsWith("t") && input.indexOf('E') > 0)
            {
                int eIndex = input.indexOf('E');
                String tempStr = input.substring(1, eIndex);
                String stateStr = input.substring(eIndex + 1);

                tempStr.trim();
                stateStr.trim();

                float tempVal = tempStr.toFloat();
                int stateVal = stateStr.toInt();

                // Validate data
                if (!isnan(tempVal) && stateVal >= 0 && stateVal <= 5)
                {
                    currentTemp = String(tempVal, 2);
                    currentStateText = STATE_NAMES[stateVal];
                    notifyClients();
                }
            }
            input = ""; // Clear for next line
        }
        else
        {
            input += c;

            // Safety: prevent buffer overflow
            if (input.length() > 30)
            {
                input = "";
            }
        }
    }
}

#endif